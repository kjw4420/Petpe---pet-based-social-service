import React, { useState } from "react";
import Container from "../components/container";
import { Link } from "react-router-dom";

const TalkTalk = () => {
  return (
    <>

      <Container>
        <h1>talktalk</h1>
      </Container>
    </>
  );
};

export default TalkTalk;
